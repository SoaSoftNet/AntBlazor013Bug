﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

namespace AntModalTest.Models
{
    public class AspNetApplicationMenuViewModel
    {
        public string RoleId { get; set; }
        public string Url { get; set; }
        public List<AspNetApplicationMenuViewModel> Children { get; set; }
        public string Id { get; set; }
        [Required(ErrorMessage = "请选择所属应用")]
        [Display(Name = "所属应用")]
        public string ApplicationId { get; set; }
        //[Required(ErrorMessage = "请选择父级菜单")]
        [Display(Name = "父级菜单")]
        public string ParentId { get; set; }
        //[Display(Name = "模块层级")]
        //public int MenuLayer { get; set; }
        [StringLength(256, ErrorMessage = "菜单名称长度为1~256")]
        [Display(Name = "菜单名称")]
        [Required(ErrorMessage = "请输入菜单名称")]
        public string MenuName { get; set; }
        [StringLength(256, ErrorMessage = "菜单编码长度为1~128")]
        [Display(Name = "菜单编码")]
        [Required(ErrorMessage = "请输入菜单编码")]
        public string MenuCode { get; set; }
        [StringLength(256, ErrorMessage = "AreaName名称长度为1~256")]
        [Display(Name = "AreaName")]
        //[Required(ErrorMessage = "请输入AreaName")]
        public string AreaName { get; set; }
        //[Required(ErrorMessage = "请输入ControllerName")]
        [StringLength(256, ErrorMessage = "ControllerName名称长度为1~256")]
        [Display(Name = "ControllerName")]
        public string ControllerName { get; set; }
        //[Required(ErrorMessage = "请输入ActionName")]
        [StringLength(256, ErrorMessage = "ActionName名称长度为1~256")]
        [Display(Name = "ActionName")]
        [Remote("ValidateActionName", "AspNetApplicationMenu", AdditionalFields = "Id,ControllerName,ActionName")]
        public string ActionName { get; set; }
        [UIHint("_EnumRadio")]
        [Display(Name = "菜单类型")]
        [Required(ErrorMessage = "请选择菜单类型")]
        public int MenuType { get; set; }
        public int MenuLayer { get; set; }
        [Display(Name = "是否展开")]
        public bool IsExpand { get; set; }
        public List<SelectListItem> ExpadItems { get; set; }
        [ScaffoldColumn(false)]
        public int PurviewNum { get; set; }
        [ScaffoldColumn(false)]
        public long PurviewSum { get; set; }

        [Display(Name = "图标")]
        public string Icon { get; set; }
        [Display(Name = "模块描述")]
        public string Description { get; set; }
        [Display(Name = "显示顺序")]
        public int SortCode { get; set; }
        [Display(Name = "验证权限")]
        public bool IsValidPurView { get; set; } = true;
        [Display(Name = "是否发布")]
        public bool Published { get; set; }
        public DateTime CreatedOn { get; set; }
        public DateTime UpdatedOn { get; set; }
        public bool Deleted { get; set; }
        public string CreatorUserId { get; set; }
        public string ModifyUserId { get; set; }
        public string DeleterUserId { get; set; }

    }
}
