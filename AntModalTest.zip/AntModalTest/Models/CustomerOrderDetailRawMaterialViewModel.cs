﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

namespace AntModalTest.Models
{
    public class CustomerOrderDetailRawMaterialViewModel
    {
        #region 公共属性
        public string Id { get; set; }
        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CustomerOrderId")]
        public string CustomerOrderId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CustomerOrderDetailId")]
        public string CustomerOrderDetailId
        {
            get;
            set;
        }
        public string RawmaterialId { get; set; }
        ///<summary>
        ///
        ///</summary>
        [Display(Name = "SupplierId")]
        public string SupplierId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "供应商")]
        public string SupplierName
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "纸厂批次")]
        public string BatchCode
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "原料编码")]
        public string RawMaterialNO
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "原料名称")]
        public string RawMaterialName
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "门幅")]
        public decimal Width
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "长度")]
        public decimal TotalLength
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "克重")]
        public decimal GramWeight
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "重量")]
        public decimal TotalWeight
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "品牌")]
        public string Brand
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Status")]
        public string Status
        {
            get;
            set;
        }
        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Remark")]
        public string Remark
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Deleted")]
        public bool Deleted
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "Creator")]
        public string Creator
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "ModifyBy")]
        public string ModifyBy
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CreatedOn")]
        public DateTime CreatedOn
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "UpdatedOn")]
        public DateTime UpdatedOn
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "CreatorUserId")]
        public string CreatorUserId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "ModifyUserId")]
        public string ModifyUserId
        {
            get;
            set;
        }

        ///<summary>
        ///
        ///</summary>
        [Display(Name = "DeleterUserId")]
        public string DeleterUserId
        {
            get;
            set;
        }

        #endregion
    }
}
